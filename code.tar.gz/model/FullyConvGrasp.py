import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import os
from model.ssd.default_bbox_generator import PriorBox
import torch.nn.init as init
from model.utils.config import cfg
from basenet.resnet import resnet18,resnet34,resnet50,resnet101,resnet152

from model.fully_conv_grasp.classifier import _Classifier
from model.fully_conv_grasp.grasp_proposal_target import _GraspTargetLayer
from model.fully_conv_grasp.bbox_transform_grasp import \
    points2labels,labels2points,grasp_encode, grasp_decode

from model.utils.net_utils import _smooth_l1_loss

class _FCGN(nn.Module):

    def __init__(self):
        super(_FCGN, self).__init__()
        self.size = cfg.FCGN.INPUT_SIZE

        self._as = cfg.FCGN.ANCHOR_SCALES
        self._ar = cfg.FCGN.ANCHOR_RATIOS
        self._aa = cfg.FCGN.ANCHOR_ANGLES
        self._fs = cfg.FCGN.FEAT_STRIDE[0]

        self.classifier = _Classifier(self.dout_base_model, 5, self._as, self._ar, self._aa)
        self.proposal_target = _GraspTargetLayer(self._fs, self._ar, self._as, self._aa)

    def forward(self, x, im_info, gt_boxes, num_boxes):
        # features
        x = self.base(x)
        pred = self.classifier(x)

        loc, conf = pred
        prob = F.softmax(conf, 1)

        bbox_loss = 0
        cls_loss = 0
        conf_label = None
        if self.training:
            # inside weights indicate which bounding box should be regressed
            # outside weidhts indicate two things:
            # 1. Which bounding box should contribute for classification loss,
            # 2. Balance cls loss and bbox loss
            loc_label, conf_label, iw, ow = self.proposal_target(pred, gt_boxes, num_boxes)
            bbox_loss = _smooth_l1_loss(loc, loc_label, iw, ow, dim = [2,1])
            conf = conf[ow > 0]
            conf_label = conf_label[ow.sum(2) > 0]
            cls_loss = F.cross_entropy(conf, conf_label)

        return loc, prob, bbox_loss , cls_loss, conf_label

    def create_architecture(self):
        self._init_modules()
        def weights_init(m):
            def xavier(param):
                init.xavier_uniform(param)
            if isinstance(m, nn.Conv2d):
                xavier(m.weight.data)
                m.bias.data.zero_()
        # initialize newly added layers' weights with xavier method
        self.classifier.loc.apply(weights_init)
        self.classifier.conf.apply(weights_init)

class resnet(_FCGN):
    def __init__(self, num_layers = 101, pretrained=False):

        self.num_layers = num_layers
        self.model_path = 'data/pretrained_model/resnet' + str(num_layers) + '_caffe.pth'
        self.dout_base_model = 2048
        self.pretrained = pretrained
        self._bbox_dim = 5
        if num_layers == 18 or num_layers == 34:
            self.expansions = 1
        elif num_layers == 50 or num_layers == 101 or num_layers == 152:
            self.expansions = 4
        else:
            assert 0, "network not defined"
        super(resnet, self).__init__()

    def _init_modules(self):
        if self.num_layers == 18:
            resnet = resnet18()
        elif self.num_layers == 34:
            resnet = resnet34()
        elif self.num_layers == 50:
            resnet = resnet50()
        elif self.num_layers == 101:
            resnet = resnet101()
        elif self.num_layers == 152:
            resnet = resnet152()
        else:
            assert 0, "network not defined"

        if self.pretrained == True:
            print("Loading pretrained weights from %s" % (self.model_path))
            state_dict = torch.load(self.model_path)
            resnet.load_state_dict({k: v for k, v in state_dict.items() if k in resnet.state_dict()})

        # Build resnet.
        self.base = nn.Sequential(resnet.conv1, resnet.bn1, resnet.relu,
                resnet.maxpool, resnet.layer1, resnet.layer2, resnet.layer3, resnet.layer4)
