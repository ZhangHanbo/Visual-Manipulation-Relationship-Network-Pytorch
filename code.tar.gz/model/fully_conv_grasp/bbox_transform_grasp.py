import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import os

import torch.nn.init as init
from model.utils.config import cfg
import numpy as np

def points2labels(points):
    """
    :param points: bs x n x 8 point array. Each line represents a grasp
    :return: label: bs x n x 5 label array: xc, yc, w, h, Theta
    """
    batch_size = points.size(0)
    label = torch.Tensor(batch_size, points.size(1), 5)
    label[:, :, 0] = (points[:, :, 0] + points[:, :, 4]) / 2
    label[:, :, 1] = (points[:, :, 1] + points[:, :, 5]) / 2
    label[:, :, 2] = torch.sqrt(torch.pow((points[:, :, 2] - points[:, :, 0]), 2)
                                + torch.pow((points[:, :, 3] - points[:, :, 1]), 2))
    label[:, :, 3] = torch.sqrt(torch.pow((points[:, :, 2] - points[:, :, 4]), 2)
                                + torch.pow((points[:, :, 3] - points[:, :, 5]), 2))
    label[:, :, 4] = torch.atan((points[:, :, 3] - points[:, :, 1]) / (points[:, :, 2] - points[:, :, 0]))
    label[:, :, 4] = label[:, :, 4] / np.pi * 180
    return label

def labels2points(label):
    pass

def grasp_encode(label, ref):
    if ref.dim() == 2:
        ref_widths = ref[:, 2]
        ref_heights = ref[:, 3]
        ref_ctr_x = ref[:, 0]
        ref_ctr_y = ref[:, 1]
        ref_angle = ref[:, 4]

        gt_widths = label[:, :, 2]
        gt_heights = label[:, :, 3]
        gt_ctr_x = label[:, :, 0]
        gt_ctr_y = label[:, :, 1]
        gt_angle = label[:, :, 5]

        targets_dx = (gt_ctr_x - ref_ctr_x.view(1,-1).expand_as(gt_ctr_x)) / ref_widths
        targets_dy = (gt_ctr_y - ref_ctr_y.view(1,-1).expand_as(gt_ctr_y)) / ref_heights
        targets_dw = torch.log(gt_widths / ref_widths.view(1,-1).expand_as(gt_widths))
        targets_dh = torch.log(gt_heights / ref_heights.view(1,-1).expand_as(gt_heights))
        targets_da = torch.div(gt_angle - ref_angle.view(1,-1).expand_as(gt_angle),
                               90 / len(cfg.FCGN.ANCHOR_ANGLES))

    elif ref.dim() == 3:
        ref_widths = ref[:, :, 2]
        ref_heights = ref[:,:, 3]
        ref_ctr_x = ref[:, :, 0]
        ref_ctr_y = ref[:, :, 1]
        ref_angle = ref[:, :, 4]

        gt_widths = label[:, :, 2]
        gt_heights = label[:, :, 3]
        gt_ctr_x = label[:, :, 0]
        gt_ctr_y = label[:, :, 1]
        gt_angle = label[:, :, 5]

        targets_dx = (gt_ctr_x - ref_ctr_x) / ref_widths
        targets_dy = (gt_ctr_y - ref_ctr_y) / ref_heights
        targets_dw = torch.log(gt_widths / ref_widths)
        targets_dh = torch.log(gt_heights / ref_heights)
        targets_da = torch.div(gt_angle - ref_angle,
                        90 / len(cfg.FCGN.ANCHOR_ANGLES))
    else:
        raise ValueError('ref_roi input dimension is not correct.')

    targets = torch.stack(
        (targets_dx, targets_dy, targets_dw, targets_dh, targets_da),2)

    return targets

def grasp_decode(encoded_label, ref):
    pass
