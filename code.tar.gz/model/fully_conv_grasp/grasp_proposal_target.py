import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import os

import torch.nn.init as init
from model.utils.config import cfg

import numpy as np
from generate_grasp_anchors import generate_oriented_anchors


from .bbox_transform_grasp import labels2points, points2labels, grasp_encode, grasp_decode

class _GraspTargetLayer(nn.Module):
    def __init__(self, feat_stride, ratios, scales, angles):
        super(_GraspTargetLayer, self).__init__()

        self.BBOX_NORMALIZE_MEANS = torch.FloatTensor(cfg.FCGN.BBOX_NORMALIZE_MEANS)
        self.BBOX_NORMALIZE_STDS = torch.FloatTensor(cfg.FCGN.BBOX_NORMALIZE_STDS)

        self.negpos_ratio = cfg.TRAIN.FCGN.NEG_POS_RATIO

        self.feat_stride = feat_stride

        self.anchors = torch.from_numpy(generate_oriented_anchors(base_size=feat_stride,
            scales=np.array(scales), ratios=np.array(ratios), angles=np.array(angles))).float()

        # [x1, y1, x2, y2] -> [xc, yc, w, h]
        self.anchors = torch.cat([
            self.anchors[:, 0:1] + self.anchors[:, 2:3] / 2,
            self.anchors[:, 1:2] + self.anchors[:, 3:4] / 2,
            self.anchors[:, 2:3] - self.anchors[:, 0:1],
            self.anchors[:, 3:4] - self.anchors[:, 1:2]
        ], dim = 1)

    def forward(self, conf, gt):
        self.batch_size = gt.size(0)

        feat_width = conf.size(2)
        feat_height = conf.size(1)

        all_anchors = self._generate_anchors(feat_height, feat_width)
        all_anchors = all_anchors.type_as(gt)
        all_anchors = all_anchors.expand(self.batch_size, all_anchors.size(1),all_anchors.size(2))

        loc_t, conf_t = self._match_gt_prior(all_anchors, gt, cfg.TRAIN.FCGN.ANGLE_THRESH)
        iw, ow = self._mine_hard_samples(conf_t, conf)

        return loc_t, conf_t, iw,ow

    def _generate_anchors(self, feat_height, feat_width):
        shift_x = np.arange(0, feat_width) * self._feat_stride
        shift_y = np.arange(0, feat_height) * self._feat_stride
        shift_x, shift_y = np.meshgrid(shift_x, shift_y)
        shifts = torch.from_numpy(np.vstack((shift_x.ravel(), shift_y.ravel())).transpose())
        shifts = torch.cat([
            shifts,
            torch.zeros(shifts.size(0), 3)
        ], dim = 1)
        shifts = shifts.contiguous().float()

        A = self._num_anchors
        K = shifts.size(0)

        # anchors = self._anchors.view(1, A, 5) + shifts.view(1, K, 5).permute(1, 0, 2).contiguous()
        anchors = self._anchors.view(1, A, 5) + shifts.view(K, 1, 5)
        anchors = anchors.view(1, K * A, 5)

        return anchors


    def _match_gt_prior(self, priors, gt, angle_thresh):
        """
        :param priors: bs x K x 5
        :param gt: bs x N x 5
        :param angle_thresh:
        :return:
        """
        x_gt = gt[:, :, 0:1].transpose(2,1)
        y_gt = gt[:, :, 1:2].transpose(2,1)
        ang_gt = gt[:, :, 4:5].transpose(2,1)
        mask_gt = (torch.sum(gt==0, 2, keepdim = True) != gt.size(2)).transpose(2,1)

        xdiff = torch.abs(priors[:, : ,0:1] - x_gt)
        ydiff = torch.abs(priors[:, :, 1:2] - y_gt)
        angdiff = torch.abs(priors[:, :, 4:5] - ang_gt)

        mask = torch.zeros_like(xdiff) + mask_gt

        match_mat = (xdiff < self.feat_stride / 2) \
                    & (ydiff < self.feat_stride / 2) \
                    & (angdiff < angle_thresh) \
                    & mask != 0
        match_num = torch.sum(match_mat, 2, keepdim = True)

        # bs x N x K ->  K x bs x N ->  K x bs x N x 1
        match_mat = match_mat.permute(2,0,1).unsqueeze(3)
        # bs x K x 5 ->  K x bs x 5 ->  K x bs x 1 x 5
        gt = gt.permute(1,0,2).unsqueeze(2)
        # K x bs x N x 5 -> bs x N x 5
        # When a prior matches multi gts, it will use
        # the mean of all matched gts as its target.
        loc = torch.sum(match_mat * gt, dim = 0) / match_num
        label = (torch.sum(match_mat, 2) > 0)

        loc_encode = grasp_encode(loc, priors)

        return loc_encode, label

    def _mine_hard_samples(self, conf_t, conf):
        """
        :param loc_t: bs x N x 5
        :param conf_t: bs x N
        :param conf: bs x N x 2
        :return:
        """
        pos = (conf_t > 0)
        batch_conf = conf.view(-1, 2)
        loss_c = self._log_sum_exp(batch_conf) - batch_conf.gather(1, conf_t.view(-1, 1))
        loss_c = loss_c.view(self.batch_size, -1)

        loss_c[pos] = 0  # filter out pos boxes for now
        _, loss_idx = loss_c.sort(1, descending=True)
        # To find element indexes that indicate elements which have highest confidence loss
        _, idx_rank = loss_idx.sort(1)
        num_pos = pos.long().sum(1, keepdim=True)
        num_neg = torch.clamp(self.negpos_ratio * num_pos, max=pos.size(1) - 1)
        neg = idx_rank < num_neg.expand_as(idx_rank)

        # Confidence Loss Including Positive and Negative Examples
        pos_idx = pos.unsqueeze(2).expand_as(conf)
        neg_idx = neg.unsqueeze(2).expand_as(conf)

        iw = pos_idx.gt(0).float() * cfg.TRAIN.FCGN.BBOX_INSIDE_WEIGHTS[0]
        if cfg.TRAIN.FCGN.BBOX_POSITIVE_WEIGHTS < 0:
            ow = (pos_idx + neg_idx).gt(0)
        else:
            ow = pos_idx.gt(0).float() * cfg.TRAIN.FCGN.BBOX_POSITIVE_WEIGHTS \
                + neg_idx.gt(0).float()

        return iw, ow

    def _log_sum_exp(self,x):
        """Utility function for computing log_sum_exp while determining
        This will be used to determine unaveraged confidence loss across
        all examples in a batch.
        Args:
            x (Variable(tensor)): conf_preds from conf layers
        """
        x_max = x.data.max()
        return torch.log(torch.sum(torch.exp(x - x_max), 1, keepdim=True)) + x_max