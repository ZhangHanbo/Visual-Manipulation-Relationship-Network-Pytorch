
def points2label(points):
    """
    :param points: 4n x 2 point array. Each 4 lines represents a grasp
    :return: label: n x 5 label array: xc, yc, w, h, Theta
    """
    pass

def label2points(label):
    pass

def grasp_encode(label, ref):
    pass

def grasp_decode(encoded_label, ref):
    pass
